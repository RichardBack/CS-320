/* Richard Backscheider
 * CS-320
 * Software Testing, Automation, and Quality Assurance
 * ContactTest.java
 */


package test;

	//Create import statements
	import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import school.Contact;

	//Create class ContactTest
	class ContactTest {

	//Test for working Contact concept//
	@Test
	void testContactClass() {
		Contact contact = new Contact("12345", "Wille", "Nelso", "9876512345", 
				"123 Kalamazoo Rd. Solomon");
		assertTrue(contact.getId().equals("12345"));
		assertTrue(contact.getFirstName().equals("Wille"));
		assertTrue(contact.getLastName().equals("Nelso"));
		assertTrue(contact.getPhone().equals("9876512345"));
		assertTrue(contact.getAddress().equals("123 Kalamazoo Rd. Solomon"));
	}
		//Test for Id too long//
		@Test
		void testSchoolContactClassIdTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class,()-> {
				new Contact("12345678912", "Wille", "Nelso", "9876512345", "123 Kalamazoo Rd. Solomon");
			});
		}
		//Test for null Id//
		@Test
		void testSchoolContactClassIdNull () {
			Assertions.assertThrows(IllegalArgumentException.class, () ->{
				new Contact (null, "Wille", "Nelso", "9876512345", "123 Kalamazoo Rd. Solomon");
			});
		}
		//Test for too long firstName//
		@Test
		void testContactfirstNameTooLong() {
			Assertions.assertThrows(IllegalArgumentException.class,()-> {
				new Contact("12345", "Willieeeeee", "Nelso", "9876512345", "123 Kalamazoo Rd. Solomon");
			});
		}
		//Test for null firstName//
		@Test
		void testSchoolContactfirstNameNull () {
			Assertions.assertThrows(IllegalArgumentException.class, () ->{
				Contact newContact = new Contact ("12345", null, "Nelso", "9876512345", "123 Kalamazoo Rd. Solomon");
			});
		}
		//Test lastName1 setter method//
		@Test
		void testContactClassSetLastName() {
			Contact newContact = new Contact ("456", "Joey", "Biden", "1231231234", "737 South Front St. California");
				newContact.setLastName ("Bidennnn");
				assertTrue(newContact.getLastName().equals("Bidennnn"));
		}
		@Test
		void testContactClassSetLastNameTooLong() {
			Contact newContact = new Contact("456", "Joey", "Biden", "1231231234", "737 South Front St. California");
				Assertions.assertThrows(IllegalArgumentException.class, () -> {
					newContact.setLastName("BidennnnTooLong");
			});
		}
		@Test
		void testContactClassSetLastNameNull() {
			Contact newContact = new Contact("456", "Joey", "Biden", "1231231234", "737 South Front St. California");
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				newContact.setLastName(null);
			});
		}
		//test phone setter method//
		void testContactClassSetPhone() {
			Contact newContact = new Contact("456", "Joey", "Biden", "1231231234", "737 South Front St. California");
			newContact.setPhone("1231231235");
				assertTrue(newContact.getPhone().equals("1231231235"));
		}
		@Test
		void testContactClassSetPhoneTooLong() {
			Contact newContact = new Contact("456", "Joey", "Biden", "1231231234", "737 South Front St. California");
				Assertions.assertThrows(IllegalArgumentException.class, () ->{
					newContact.setPhone("11223311223311223344");
			});
		}
		@Test
		void testContactClassSetPhoneNull() {
			Contact newContact = new Contact("456", "Joey", "Biden", "1231231234", "737 South Front St. California");
			Assertions.assertThrows(IllegalArgumentException.class, ()-> {
				newContact.setPhone(null);
			});
		}
		@Test
		void testCotnactClassSetPhoneTooShort() {
			Contact newContact = new Contact("456", "Joey", "Biden", "1231231234", "737 South Front St. California");
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setPhone("1238");
			});
		}
		//test address1 setter method//
		@Test
		void testContactClassSetAddress() {
			Contact newContact = new Contact ("456", "Joey", "Biden", "1231231234", "737 South Front St. California");
			newContact.setAddress ("737SouthFrontSt.California123");
			assertTrue(newContact.getAddress().equals("737SouthFrontSt.California123"));
		}
		@Test
		void testContactClassSetaddressTooLong() {
			Contact newContact = new Contact("456", "Joey", "Biden", "1231231234", "737 South Front St. California");
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setAddress("737SouthFrontSt.California123TooLong");
		});
	}
		@Test
		void testContactClassSetaddressNull() {
			Contact newContact = new Contact("456", "Joey", "Biden", "1231231234", "737 South Front St. California");
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setAddress(null);
		});
	}
}