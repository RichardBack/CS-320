/* Richard Backscheider
 * CS-320
 * Software Testing, Automation, and Quality Assurance
 * ContactServiceTest
 */

package test;

	//Create import statements
	import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import school.Contact;
import school.ContactService;

	//create class ContactServiceTest
	class ContactServiceTest {

	//Create a contact and test values
	// This creates contacts with a unique ID using the ContactService addContact method
	
	@Test
	void testContactServiceClass() {
		ContactService.addContact("Wille", "Nelson", "9876512345", "123 Kalamazoo Rd. Solomon");
		
		//System.out.println(ContactService.contactList.get(0).getId());	used for debugging
		
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("Wille"));
		assertTrue(ContactService.contactList.get(0).getLastName().equals("Nelson"));
		assertTrue(ContactService.contactList.get(0).getPhone().equals("9876512345"));
		assertTrue(ContactService.contactList.get(0).getAddress().equals("123 Kalamazoo Rd. Solomon"));
	}
	
	//Confirm deletion of a contact
	
	@Test
	void testContactServiceDelete() {
		ContactService.addContact("Wille", "Nelson", "9876512345", 
				"123 Kalamazoo Rd. Solomon");
		int size = ContactService.contactList.size();
		
	//System.out.println(ContactService.contactList.get(size - 1).getId());
		
		ContactService.deleteContact("1234500003");
		
	//ContactService.searchContact("1234500003");
		
	//System.out.println(ContactService.contactList.get(1).getId());
		
		assertTrue(ContactService.searchContact("1234500003") == 2);
	}
	
	//Update first name test
	
	@Test
	void testContactServiceUpdateFirstName() {
		ContactService.addContact("Joey", "Pres Biden", "9876512345", "1600 Penns Ave");
		int size = ContactService.contactList.size();
		
		ContactService.updateFirstName("1234500003", "Bill");
	}
	
	//Using 1234500003 to test the rest
	//Test confirming update to last name
	@Test
	void testContactServiceUpdateLastName() {
		int size = ContactService.contactList.size();
		ContactService.updateLastName("1234500003", "Clinton");
	}
	
	//Test confirming update to phone number
	@Test
	void testContactServiceUpdatePhone() {
		int target = ContactService.findIndex("1234500003");
		ContactService.updatePhoneNumber("1234500003", "9876512345");
		assertTrue(ContactService.contactList.get(target).getPhone().equals("9876512345"));
	}
	
	//Test confirming update to address
	@Test
	void testContactServiceUpdateAddress() {
		int target = ContactService.findIndex("1234500003");
		ContactService.updateAddress("1234500003", "455 Main St. Farmington, NH");
		assertTrue(ContactService.contactList.get(target).getAddress().equals("455 Main St. Farmington, NH"));
	}
	
	//Test to confirm unique ID
	@Test
	void testContactServiceUniqueId() {
		Contact newContact = new Contact("73737", "Joseph", "BarackO", "9876512345", "Original Contact Address");
		ContactService.addContact(newContact);
		Contact duplicateId;
		}
	}