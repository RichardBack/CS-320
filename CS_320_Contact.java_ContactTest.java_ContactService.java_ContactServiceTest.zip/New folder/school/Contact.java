/* Richard Backscheider
 * CS-320
 * Software Testing, Automation, and Quality Assurance
 * Contact.java
 */

package school; 

//Create public class Contact
public class Contact { 

	//Create variables for class//
	private String id; 
	private String firstName; 
	private String lastName;
	private String phone;
	private String address; 
	
	//Create an object of the class//
	public Contact (String id, String firstName, String lastName, String phone, String address) {
	
		//Check Contact Class Requirements for ID//
		if(id == null || id.length()>10) {
			throw new IllegalArgumentException("Invalid id");
		}
		
		//Check Contact Class Requirements for FirstName//
		if(firstName == null || firstName.length()>10){ 
			throw new IllegalArgumentException("Invalid first name"); 
		}
		
		//Check Contact Class Requirements for LastName//
		if(lastName == null || lastName.length()>10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		
		//Check Contact Class Requirements for phone//
		if(phone == null || phone.length()!=10) {
			throw new IllegalArgumentException("Invalid phone");
		}
			for (int i = 0; i < phone.length(); i++) { 
			if (! Character.isDigit(phone.charAt(i))) {
			throw new IllegalArgumentException("Invalid phone number");
		}
	}
			
		//Check Contact Class Requirements for address//
		if(address == null || address.length()>30) {
			throw new IllegalArgumentException("Invalid address");
		}
		
		//Handle assuming no exceptions//
		this.id = id;
		this.firstName = firstName; 
		this.lastName = lastName;
		this.phone = phone;
		this.address = address; 
		}
	
	//Getter methods
	public String getId() {
		return id;
	}
	public String getFirstName() {
	    return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getPhone() {
		return phone;
	}
	public String getAddress() {
		return address;
	}
	
	//Setter methods for ContactService
	//Requirements for Id: Id shall not be updatable--no set method//
	public void setFirstName(String firstName1) {
		if (firstName1 == null || firstName1.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		this.firstName = firstName1;
	}
	public void setLastName(String lastName1) {
		if (lastName1 == null || lastName1.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		this.lastName = lastName1;
	}
	public void setPhone(String Phone) {
		if (Phone == null ||Phone.length() != 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		this.phone = Phone;
	}
	public void setAddress(String address) {
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		this.address = address;
	}
}