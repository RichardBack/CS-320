/* Richard Backscheider
 * CS-320
 * Software Testing, Automation, and Quality Assurance
 * ContactService.java
 */

package school;

//Create import statements
import java.util.ArrayList;

//Create public class ContactService
public class ContactService {

  public static ArrayList<Contact> contactList = new ArrayList<>();

  private static String generateUniqueId() {
    String uniqueId;

    //Include if, else statement
    if (contactList.isEmpty()) {
      uniqueId = "1234500001";
    } else {
      int arraySize = contactList.size();
      uniqueId = contactList.get(arraySize - 1).getId();
      int tempInt = Integer.valueOf(uniqueId);
      tempInt += 1;
      uniqueId = Integer.toString(tempInt);
    }

    return uniqueId;
  }

  public static void addContact(String firstName, String lastName, String phone, String address) {
    String id = generateUniqueId();
    Contact contact = new Contact(id, firstName, lastName, phone, address);
    contactList.add(contact);
  }

  public static void addContact(Contact contact) {
    String id = contact.getId();
    for (Contact c : contactList) {
      if (id.equals(c.getId())) {
        throw new IllegalArgumentException("Contact ID Must Be Unique");
      }
    }
    contactList.add(contact);
  }

  public static void updateFirstName(String id, String firstName) {
    int index = findIndex(id);
    if (index != -1) {
      contactList.get(index).setFirstName(firstName);
    }
  }

  public static void updateLastName(String id, String lastName) {
    int index = findIndex(id);
    if (index != -1) {
      contactList.get(index).setLastName(lastName);
    }
  }

  public static void updatePhoneNumber(String id, String phone) {
    int index = findIndex(id);
    if (index != -1) {
      contactList.get(index).setPhone(phone);
    }
  }

  public static void updateAddress(String id, String address) {
    int index = findIndex(id);
    if (index != -1) {
      contactList.get(index).setAddress(address);
    }
  }

  public static void deleteContact(String id) {
    int index = findIndex(id);
    if (index != -1) {
      contactList.remove(index);
    }
  }

  public static int searchContact(String id) {
    int index = findIndex(id);
    return (index != -1) ? 1 : 2;
  }

  public static int findIndex(String id) {
    int result = -1;
    for (int i = 0; i < contactList.size(); i++) {
      if (id.compareTo(contactList.get(i).getId()) == 0) {
        result = i;
        break;
      }
    }
    return result;
  }
}
